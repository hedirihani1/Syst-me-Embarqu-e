// ________________________________________________________________________________________
//                                     Bibliothèques                                                                                                                              
// ________________________________________________________________________________________
 
#include <Arduino.h>
#include <SparkFunBME280.h>
#include <Wire.h>
#include <SD.h>                   // Gestion de la carte SD (Read, Write, ...)
 
//#define BT_V 2
//#define BT_R 3
//#define LumPin A2
const int pinSD = 4;                // Lecteur SD
 
// ________________________________________________________________________________________
//                                       Déclarations
// ________________________________________________________________________________________
 
// Capteurs ____________________________________________________
#define pinGreenButton 2          // Green button (interruption)
#define pinRedButton 3            // Red button (interruption)
#define pinLumSensor A2           // Analogic pin
BME280 tphSensor;                 // BME280
 
// Variables ____________________________________________________
struct datas {
  float Lum;
  float Pre;
  float Hum;
  float Tem;
};
 
// Fonction ____________________________________________________
void sensorsReading(float* L, float* P, float* H, float* T){
  *L = analogRead(pinLumSensor);
  *P = tphSensor.readFloatPressure();
  *H = tphSensor.readFloatHumidity();
  *T = tphSensor.readTempC();
}
 
void saveData(float* L, float* P, float* H, float* T) { // Hedi
    File dataFile = SD.open("logs.txt", FILE_WRITE);
   
    if (dataFile) {
        // Sauvegarde des données des capteurs dans le fichier
        dataFile.print("Luminosité: ");
        dataFile.println(*L);
        dataFile.print("Pression: ");
        dataFile.print(*P/100);
        dataFile.println("hPa");
        dataFile.print("Humidité: ");
        dataFile.print(*H);
        dataFile.println("percent");
        dataFile.print("Température: ");
        dataFile.print(*T);
        dataFile.println("°C");
        dataFile.println("__");
       
        dataFile.close();
        Serial.println("Données sauvegardées sur la carte SD.");
    } else {
        // Si l'ouverture échoue
        Serial.println("Erreur lors de l'ouverture du fichier datalog.txt sur la carte SD.");
    }
}
 
 
// ________________________________________________________________________________________
//                                       Exécution
// ________________________________________________________________________________________
 
void setup() {
  Serial.begin(9600);
  delay(1000);
  Wire.begin();
  tphSensor.setI2CAddress(0x76);
 
  while (!Serial) {}
    Serial.print("Initializing SD card...");
 
    if (!SD.begin(pinSD)) {
      Serial.println("Card failed, or not present");
      while (1);
    }
    Serial.println("card initialized.");
 
  if (tphSensor.beginI2C()) {
    Serial.println("BME280 initialisé avec succès");
 
    tphSensor.setMode(MODE_NORMAL); // MODE_SLEEP, MODE_FORCED, MODE_NORMAL
   
    Serial.println("Configuration BME280 terminée");
  } else {
    Serial.println("Erreur d'initialisation BME280");
  }
 
  pinMode(pinLumSensor, INPUT);
}
 
void loop() {
  struct datas sensorValues;     // Instance de la structure data
 
  // Lecture des données et stockage dans la structure
  sensorsReading(&(sensorValues.Lum), &(sensorValues.Pre), &(sensorValues.Hum), &(sensorValues.Tem));

  Serial.print("Luminosité : ");
  Serial.println(sensorValues.Lum);
 
  Serial.print("Pression : ");
  Serial.print(sensorValues.Pre/100);
  Serial.println("hPa");
 
  Serial.print("Humidité : ");
  Serial.print(sensorValues.Hum);
  Serial.println("%");
 
  Serial.print("Température : ");
  Serial.print(sensorValues.Tem);
  Serial.println("°C");


  saveData(&(sensorValues.Lum), &(sensorValues.Pre), &(sensorValues.Hum), &(sensorValues.Tem));
 
  delay(1000); // Délai pour ne pas surcharger le port série
}