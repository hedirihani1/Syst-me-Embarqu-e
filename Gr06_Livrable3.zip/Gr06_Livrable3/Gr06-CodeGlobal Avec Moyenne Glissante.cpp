// ________________________________________________________________________________________
//                                     Bibliothèques                                                                                                                               
// ________________________________________________________________________________________
#include <Arduino.h>
#include <ChainableLED.h>
#include <SparkFunBME280.h>
#include <Wire.h>
#include <SD.h>
#include <SoftwareSerial.h>
//#include <DS1307.h>
//#include <EEPROM.h>


// ________________________________________________________________________________________
//                                       Déclarations
// ________________________________________________________________________________________

// Capteurs ____________________________________________________
#define pinGreenButton 3          // Green button (interruption)
#define pinRedButton 2            // Red button (interruption)
#define pinLumSensor A2           // Analogic pin
#define TAILLE_FENETRE 10         // Taille de la fenêtre pour la moyenne glissante
const int pinSD = 4;              // Lecteur SD
BME280 tphSensor;                 // BME280
ChainableLED leds(7,8,1);         // ChainableLED leds(PIN_A, PIN_B, NOMBRE_DE_LEDS)
//DS1307 clock;
//SoftwareSerial SoftSerial(5,6);   // Communication série GPS

// Variables ____________________________________________________
int mode = 0;                     // mode standard = 0 , mode config=1, mode maintenance=2, mode éco=3
byte prec;                        // mode précédent standard = 0; Economie = 1
volatile int lastPush;            // Dernière pression sur un bouton
volatile int currentMillis;       //stocker le temps actuel
volatile int data;                // stocker l'état du bouton

struct datas {
  float Lum;
  float Pre;
  float Hum;
  float Tem;
};

// Paramètres ____________________________________________________

unsigned long LOG_INTERVAL = 1000;

// ________________________________________________________________________________________
//                                       Signatures
// ________________________________________________________________________________________

void interruption ();
void changeRedButton ();
void changeGreenButton();

void configMode();
void standardMode();
void maintenanceMode();
void ecoMode();

void sensorsReading(float* L, float* P, float* H, float* T);
void printData(float* L, float* P, float* H, float* T);
void saveData(float* L, float* P, float* H, float* T);

String getTime();
//void settings();
void signalerErreurSD();


// ________________________________________________________________________________________
//                                       Exécution
// ________________________________________________________________________________________

void setup(){
  Serial.begin(9600);
  delay(1000);
  Wire.begin();
  tphSensor.setI2CAddress(0x76);

  while (!Serial) {}
  Serial.println("Initialisation SD...");
 
  if (!SD.begin(pinSD)) {
    Serial.println("Erreur carte SD");
    signalerErreurSD();
    while(1);
  }
  Serial.println("Carte SD initialisee.");
 
  if (tphSensor.beginI2C()) {
    Serial.println("BME280 initialise avec succès");
    tphSensor.setMode(MODE_NORMAL); // MODE_SLEEP, MODE_FORCED, MODE_NORMAL
    Serial.println("Configuration BME280 terminee");
  } 
  else {
    Serial.println("Erreur d initialisation BME280");
  }

  //EEPROM.put(0, 10); //LOG_INTERVAL=100
  
  pinMode(pinLumSensor, INPUT);
  pinMode(pinGreenButton, INPUT_PULLUP);
  pinMode(pinRedButton, INPUT_PULLUP);
  interruption();

  if (digitalRead(pinRedButton) == LOW) {      // Vérifier si le bouton rouge est pressé au démarrage
      configMode(); // Passer en mode configuration
    }
    else{
      standardMode();
    }
}

void loop(){
  struct datas sensorValues;
  sensorsReading(&(sensorValues.Lum), &(sensorValues.Pre), &(sensorValues.Hum), &(sensorValues.Tem));
  if(mode==0 || mode==3){
    saveData(&(sensorValues.Lum), &(sensorValues.Pre), &(sensorValues.Hum), &(sensorValues.Tem));
  }
  if(mode==2){
    printData(&(sensorValues.Lum), &(sensorValues.Pre), &(sensorValues.Hum), &(sensorValues.Tem));
  }
  delay(LOG_INTERVAL);
  //delay(1000);
}

// ________________________________________________________________________________________
//                                       Fonctions
// ________________________________________________________________________________________

void interruption (){
    attachInterrupt(digitalPinToInterrupt(pinGreenButton), changeGreenButton, CHANGE);
    attachInterrupt(digitalPinToInterrupt(pinRedButton), changeRedButton, CHANGE);
}

volatile unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;

void changeRedButton (){
  Serial.println("Rouge");
  currentMillis = millis();
  if ((currentMillis - lastDebounceTime) > debounceDelay) {
    data = digitalRead(pinRedButton); // Lire l'état actuel
    lastDebounceTime = currentMillis; // Mémoriser le temps du dernier changement
  
  if (data == LOW) {
  	lastPush = currentMillis;
    //Serial.println("Bouton Rouge appuye");  
  }
  if (currentMillis - lastPush >= 5000){
    //Serial.println("Rouge appuyé 5s");
    lastPush=0;
    if (mode==0 || mode==3) {
        maintenanceMode();
    }
  }
}
}
void changeGreenButton(){
  Serial.println("Vert");
  currentMillis = millis();
  if ((currentMillis - lastDebounceTime) > debounceDelay) {
    data = digitalRead(pinRedButton); // Lire l'état actuel
    lastDebounceTime = currentMillis; // Mémoriser le temps du dernier changement
  
  data = digitalRead(pinGreenButton);
  
  if ((data == LOW)) {
  	lastPush = currentMillis;
    //Serial.println("Bouton Vert appuye");
  } 
  
  if (currentMillis - lastPush >= 5000){
    //Serial.println("Vert appuyé 5s");
    lastPush=0;
    if (mode==0) {
      ecoMode();
    }
    else if (mode==3) {
  		standardMode();
    }
    else if (mode==2) {
      if (prec == 0) {
  		  standardMode();
      }
      else if (prec == 1) {
        ecoMode();
      }
      
    }
  }
}
}

void standardMode(){
  Serial.println("________________ MODE STANDARD ________________");
  LOG_INTERVAL = 1000;
  mode = 0;                         // 0 = Mode Standard
  prec = 0;

  if (!SD.begin(pinSD)) {
    Serial.println("Erreur carte SD");
    signalerErreurSD();
  }
  Serial.println("Carte SD initialisee.");

  leds.setColorRGB(0, 0, 255, 0); // (numLED, R, G, B) mets en led verte
}

void configMode(){
    Serial.println("________________ MODE CONFIGURATION ________________");
    mode = 1;
    leds.setColorRGB(0, 255, 255, 0); // (numLED, R, G, B)  
}

void maintenanceMode(){
  Serial.println("________________ MODE MAINTENANCE ________________");
  mode = 2;
  LOG_INTERVAL = 1000;

  SD.end();
  //Serial.print("Carte SD éjectée"); //Pose problème

  leds.setColorRGB(0, 255, 128, 0); // (numLED, R, G, B)
}

void ecoMode(){
  Serial.println("________________ MODE ECONOMIQUE ________________");
  LOG_INTERVAL = 2000;
  mode=3;
  prec = 1;

  if (!SD.begin(pinSD)) {
    Serial.println("Erreur carte SD");
    signalerErreurSD();
  }
  Serial.println("Carte SD initialisee.");

  leds.setColorRGB(0, 0, 0, 255); // (numLED, R, G, B)
}

float valeursLuminosite[TAILLE_FENETRE] = {0};  // Tableau pour la luminosité
float valeursPression[TAILLE_FENETRE] = {0};    // Tableau pour la pression
float valeursHumidite[TAILLE_FENETRE] = {0};    // Tableau pour l'humidité
float valeursTemperature[TAILLE_FENETRE] = {0}; // Tableau pour la température
int indice = 0;                                 // Indice pour remplir le tableau circulaire

void sensorsReading(float* L, float* P, float* H, float* T) {
    // Acquisition des données
    *L = analogRead(pinLumSensor);
    *P = tphSensor.readFloatPressure();
    *H = tphSensor.readFloatHumidity();
    *T = tphSensor.readTempC();
  
    // Stockage dans les tableaux circulaires
    valeursLuminosite[indice] = *luminosite;
    valeursPression[indice] = *pression;
    valeursHumidite[indice] = *humidite;
    valeursTemperature[indice] = *temperature;
    
    // Calcul de la moyenne glissante
    *luminosite = calculMoyenneGlissante(valeursLuminosite);
    *pression = calculMoyenneGlissante(valeursPression);
    *humidite = calculMoyenneGlissante(valeursHumidite);
    *temperature = calculMoyenneGlissante(valeursTemperature);
  
    // Mise à jour de l'indice
    indice = (indice + 1) % TAILLE_FENETRE;  // Remet l'indice à 0 quand on atteint TAILLE_FENETRE
}

float calculMoyenneGlissante(float valeurs[]) {
    float somme = 0;
    for (int i = 0; i < TAILLE_FENETRE; i++) {
        somme += valeurs[i];
    }
    return somme / TAILLE_FENETRE;
}


void saveData(float* L, float* P, float* H, float* T){
    //File dataFile = SD.open("logs.txt", FILE_WRITE);
    File dataFile = SD.open("data.txt", FILE_WRITE);
   
    if (dataFile) {
        // Sauvegarde des données des capteurs dans le fichier
        dataFile.print("Luminosité: ");
        dataFile.print(*L);
        dataFile.print("      ");
        dataFile.print("Pression: ");
        dataFile.print(*P/100);
        dataFile.print("hPa");
        dataFile.print("      ");
        dataFile.print("tHumidité: ");
        dataFile.print(*H);
        dataFile.print("percent");
        dataFile.print("      ");
        dataFile.print("Température: ");
        dataFile.print(*T);
        dataFile.println("°C");
        
       
        dataFile.close();
        Serial.println("Backup SD - ok");
    } else {
        // Si l'ouverture échoue
        Serial.println("Erreur SD");
        //signalerErreurSD();
    }

}

void printData(float* L, float* P, float* H, float* T){
  Serial.print("Luminosité : ");
  Serial.print(*L);
  Serial.print("      ");
  Serial.print("Pression : ");
  Serial.print(*P/100);
  Serial.print("hPa");
  Serial.print("      ");
  Serial.print("Humidité : ");
  Serial.print(*H);
  Serial.print("%");
  Serial.print("      ");
  Serial.print("Température : ");
  Serial.print(*T);
  Serial.println("°C");
}

void signalerErreurSD() {
  // Mode erreur : clignotement en alternant rouge et blanc
  while (true) {  // Boucle infinie en cas d'erreur
    leds.setColorRGB(0, 255, 0, 0);      // Rouge
    delay(500);
    leds.setColorRGB(0, 255, 255, 255);  // Blanc
    delay(1000);
  }
}

/*
String getTime(){
    String time="";
    clock.getTime();
    time+=String(clock.hour, DEC);
    time+=String(":");
    time+=String(clock.minute, DEC);
    time+=String(":");
    time+=String(clock.second, DEC);
    time+=String("  ");
    time+=String(clock.month, DEC);
    time+=String("/");
    time+=String(clock.dayOfMonth, DEC);
    time+=String("/");
    time+=String(clock.year+2000, DEC);
    time+=String(" ");
    time+=String(clock.dayOfMonth);
    time+=String("*");
    switch (clock.dayOfWeek)// Friendly printout the weekday
    {
        case MON:
        time+=String("MON");
        break;
        case TUE:
        time+=String("TUE");
        break;
        case WED:
        time+=String("WED");
        break;
        case THU:
        time+=String("THU");
        break;
        case FRI:
        time+=String("FRI");
        break;
        case SAT:
        time+=String("SAT");
        break;
        case SUN:
        time+=String("SUN");
        break;
    }
    time+=String(" ");
    return time;
}
*/


