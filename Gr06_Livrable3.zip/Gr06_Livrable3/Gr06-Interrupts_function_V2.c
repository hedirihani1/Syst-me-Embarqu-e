// ________________________________________________________________________________________
//                                     Bibliothèques                                                                                                                               
// ________________________________________________________________________________________
#include <Arduino.h>              // Gestion I/O, broches, temps, ...
#include <ChainableLED.h>         // Gestion des LEDs RGB

// ________________________________________________________________________________________
//                                       Déclarations
// ________________________________________________________________________________________

// Capteurs ____________________________________________________
#define pinGreenButton 3         // Green button (interruption)
#define pinRedButton 2            // Red button (interruption)
ChainableLED leds(7,8,1);         // ChainableLED leds(PIN_A, PIN_B, NOMBRE_DE_LEDS)

// Variables ____________________________________________________
int mode = 0;                     // mode standard = 0 , mode config=1, mode maintenance=2, mode éco=3
byte prec;                        // mode précédent standard = 0; Economie = 1
volatile int lastPush;            // Dernière pression sur un bouton
volatile int currentMillis;       //stocker le temps actuel
volatile int data;                // stocker l'état du bouton

volatile unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;

// ________________________________________________________________________________________
//                                       Signatures
// ________________________________________________________________________________________
void interruption ();       // Done
void changeRedButton ();    // Done
void changeGreenButton();   // Arthur

void configMode();          // Arthur
void standardMode();        // Robin
void maintenanceMode();     // Hedi
void ecoMode();             // Elio

// ________________________________________________________________________________________
//                                       Exécution
// ________________________________________________________________________________________

void setup(){
    Serial.begin(9600);
    interruption();
    pinMode(pinGreenButton, INPUT_PULLUP);       // Initialisation boutons
    pinMode(pinRedButton, INPUT_PULLUP);         // Initialisation boutons
    // Vérifier si le bouton rouge est pressé au démarrage
    if (digitalRead(pinRedButton) == LOW) {      // Vérifier si le bouton rouge est pressé au démarrage
      configMode(); // Passer en mode configuration
    }
    else{
      standardMode();
    }
    
 
}

void loop(){


}

// ________________________________________________________________________________________
//                                       Fonctions
// ________________________________________________________________________________________

void interruption (){
    attachInterrupt(digitalPinToInterrupt(pinGreenButton), changeGreenButton, CHANGE);
    attachInterrupt(digitalPinToInterrupt(pinRedButton), changeRedButton, CHANGE);
}



void changeRedButton (){
  Serial.println("Interrup");
  currentMillis = millis();
  if ((currentMillis - lastDebounceTime) > debounceDelay) {
    data = digitalRead(pinRedButton); // Lire l'état actuel
    lastDebounceTime = currentMillis; // Mémoriser le temps du dernier changement
  
  if (data == LOW) {
  	lastPush = currentMillis;
    Serial.println("Bouton Rouge appuye");  
  }
  if (currentMillis - lastPush >= 5000){
    Serial.println("Rouge appuyé 5s");
    lastPush=0;
    if (mode==0 || mode==3) {
        maintenanceMode();
    }
    
  }
}
}

void changeGreenButton(){
  Serial.println("Interrup");
  currentMillis = millis();
  if ((currentMillis - lastDebounceTime) > debounceDelay) {
    data = digitalRead(pinGreenButton); // Lire l'état actuel
    lastDebounceTime = currentMillis;   // Mémoriser le temps du dernier changement
  
  data = digitalRead(pinGreenButton);
  
  if ((data == LOW)) {
  	lastPush = currentMillis;
    Serial.println("Bouton Vert appuye");
  } 
  
  if (currentMillis - lastPush >= 5000){
    Serial.println("Vert appuyé 5s");
    lastPush=0;
    if (mode==0) {
      ecoMode();
    }
    else if (mode==3) {
  		standardMode();
    }
    else if (mode==2) {
      if (prec == 0) {
  		  standardMode();
      }
      else if (prec == 1) {
        ecoMode();
      }
    }
  }
}
}

void standardMode(){
  Serial.print("________________ MODE STANDARD ________________");
  mode = 0;                         // 0 = Mode Standard
  prec = 0;
  leds.setColorRGB(0, 0, 255, 0); // (numLED, R, G, B) - LED VERTE
}

void configMode(){
    Serial.print("________________ MODE CONFIGURATION ________________");
    mode = 1;
    leds.setColorRGB(0, 255, 255, 0); // (numLED, R, G, B)   - LED JAUNE
}

void maintenanceMode(){
  Serial.print("________________ MODE MAINTENANCE ________________");
  mode = 2;
  leds.setColorRGB(0, 255, 128, 0); // (numLED, R, G, B) - LED ORANGE
}

void ecoMode(){
  Serial.print("________________ MODE ECONOMIQUE ________________");
    mode=3;
    prec = 1;
    leds.setColorRGB(0, 0, 0, 255); // (numLED, R, G, B) - LED BLEU
}

