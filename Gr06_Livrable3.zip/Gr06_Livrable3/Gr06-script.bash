#!/bin/bash

# Dossier du script et options
SCRIPT_DIR="$(dirname "$0")"
FOLDER="$SCRIPT_DIR"
PORT=""

# Traitement des arguments
for arg in "$@"; do
    case "$arg" in
        f=*) FOLDER="${arg#*=}" ;;
        p=*) PORT="${arg#*=}" ;;
    esac
done

# Vérifie si le dossier existe
if [ ! -d "$FOLDER" ]; then
    echo "Erreur : le dossier $FOLDER n'existe pas."
    exit 1
fi

# Création des dossiers nécessaires
mkdir -p "$FOLDER/build" "$FOLDER/.tmp"
cd "$FOLDER" || exit 1

# Compilation des fichiers .c
filesC=""
for c in *.c; do
    [ -f "$c" ] || continue
    avr-gcc -Os -DF_CPU=16000000UL -mmcu=atmega328p -c "$c" -o ".tmp/${c%.*}.o" && \
    filesC="$filesC .tmp/${c%.*}.o" || echo "Erreur de compilation de $c"
done

# Edition des liens
avr-gcc -DF_CPU=16000000UL -mmcu=atmega328p $filesC -o build/firmware.elf

# Création du fichier HEX
avr-objcopy -O ihex -R .eeprom build/firmware.elf build/firmware.hex

# Téléversement vers l'Arduino
if [ -z "$PORT" ]; then
    echo "Erreur : aucun port spécifié. Utilisez l'option p=<port>."
    exit 1
fi
avrdude -V -patmega328p -carduino -P"$PORT" -b115200 -D -Uflash:w:build/firmware.hex:i && \
echo "Téléversement réussi." || echo "Erreur lors du téléversement."

# Affichage des fichiers dans le dossier build
ls -l build
