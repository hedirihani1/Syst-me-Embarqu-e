#include <Arduino.h>  // Bibliothèque principale pour le développement Arduino
#include <EEPROM.h> 
//#include "DS1307.h"


#define VERSION "v1.0.0"
#define LOT "20241030-001"



int mode = 0;                     // mode standard = 0 , mode config=1, mode maintenance=2, mode éco=3
void settings();

void configMode();
void setup()
{
  Serial.begin(9600);

  int LUMIN_TEST;
  EEPROM.get(6, LUMIN_TEST);
  if (LUMIN_TEST != 0 && LUMIN_TEST != 1) { // verification par un parametre, si les parametres ont déjà été initalisé sur l'arduino
    settings();
    Serial.println("réinitialisation de l’ensemble des paramètres à leurs valeurs par défaut.");
  }

  configMode();
}

void settings() // fonction permettant de définir les paramètres de base dans l'EEPROM
{
  //si c'est un int ca prent 2 octets donc 2 en 2 si c'est un boll un seul
    EEPROM.put(0, 10); //LOG_INTERVAL=100
    EEPROM.put(2, 4096); //FILE_MAX_SIZE
    EEPROM.put(4, 3000); //TIMEOUT
    EEPROM.put(6, 1); //LUMIN
    EEPROM.put(7, 255); // LUMIN_LOW=254
    EEPROM.put(9, 768); //LUMIN_HIGH
    EEPROM.put(11, 1); //TEMP_AIR
    EEPROM.put(12, -10); //MIN_TEMP_AIR
    EEPROM.put(14, 60); //MAX_TEMP_AIR
    EEPROM.put(15, 1); //HYGR
    EEPROM.put(16, 0); //HYGR_MINT
    EEPROM.put(18, 50); //HYGR_MAXT
    EEPROM.put(19, 1); //PRESSURE
    EEPROM.put(20, 850); //PRESSURE_MIN
    EEPROM.put(22, 1080); //PRESSURE_MAX

}


void configMode() { 

  int LUMIN_LOW, LUMIN_HIGH, MIN_TEMP_AIR, MAX_TEMP_AIR,
    HYGR_MINT, HYGR_MAXT, PRESSURE_MIN, PRESSURE_MAX,
    LOG_INTERVAL, FILE_MAX_SIZE, TIMEOUT, LUMIN, TEMP_AIR, HYGR, PRESSURE;

  unsigned long dernierTempsActivite = 0; // stocke le dernier temps de l'activité
  const unsigned long delaiInactivite = 30000; // 30 minutes en millisecondes (mis a 30 secondes pour le test)

  mode = 1;
  Serial.println("________________ MODE CONFIGURATION ________________");
  Serial.println("Entrez une commande :");
  while (true) {
    // attendre que l'utilisateur entre une commande
      if (millis() - dernierTempsActivite >= delaiInactivite) { // verification du temsp d'inactivité avant le retour au mode standard
        void standardMode();    
      return;
    }

  if (Serial.available() > 0) {
  dernierTempsActivite = millis(); // Réinitialiser le temps d'activité car une commande a été reçue
  String commande = Serial.readStringUntil('\n'); // recup la commande entrer par le user
  commande.trim(); //suprimer les characteres invisibles
  

  if (commande == "RESET") {
        settings();
        Serial.println("Réinitialisation de l’ensemble des paramètres à leurs valeurs par défaut.");
  } else if (commande == "VERSION") {
        Serial.print("Version: ");
        Serial.println(VERSION);
        Serial.print("Lot: ");
        Serial.println(LOT);

  } else {
  int egal = commande.indexOf('='); // stock la position de l'egal

  if (egal != -1) {                 // verifie si l'egal existe
    String var = commande.substring(0, egal);         //stock dans var ce qu'il y a avant le =
    String valeur = commande.substring(egal + 1);     //stock dans valeur ce qu'il y a apres le =
  
    int valeurInt = valeur.toInt(); // Convertir la valeur en entier

    if (var == "CLOCK") { 
      int h = valeur.substring(0, valeur.indexOf(':')).toInt();
      int m = valeur.substring(valeur.indexOf(':') + 1, valeur.lastIndexOf(':')).toInt();
      int s = valeur.substring(valeur.lastIndexOf(':') + 1).toInt();

      if (h >= 0 && h <= 23 && m >= 0 && m <= 59 && s >= 0 && s <= 59) {
      //  rtc.setTime(h, m, s); 
        Serial.println("Heure configurée avec succès !");
      } else {
        Serial.println("Erreur : Heure invalide.");
      }
    } else if (var == "DATE") {  // FORMAT Attendu: DATE=Jours,Mois,Années
      String dateString = commande.substring(5);
      int mois = dateString.substring(0, dateString.indexOf(',')).toInt();
      int jour = dateString.substring(dateString.indexOf(',') + 1, dateString.lastIndexOf(',')).toInt();
      int annee = dateString.substring(dateString.lastIndexOf(',') + 1).toInt();

      if (mois >= 1 && mois <= 12 && jour >= 1 && jour <= 31 && annee >= 2000 && annee <= 2099) {
        //rtc.setDate(jour, mois, annee); 
        Serial.println("Date configurée avec succès !");
      } else {
        Serial.println("Erreur : date invalide.");
      }
    } else if (commande.startsWith("DAY=")) {
      String jourSemaine = commande.substring(4);
      uint8_t dayOfWeek;

    if (jourSemaine == "SUN") dayOfWeek = 0;
    else if (jourSemaine == "MON") dayOfWeek = 1;
    else if (jourSemaine == "TUE") dayOfWeek = 2;
    else if (jourSemaine == "WED") dayOfWeek = 3;
    else if (jourSemaine == "THU") dayOfWeek = 4;
    else if (jourSemaine == "FRI") dayOfWeek = 5;
    else if (jourSemaine == "SAT") dayOfWeek = 6;


    //rtc.setDayOfWeek(dayOfWeek); = 
    Serial.println("Jour de la semaine configuré avec succès !");

    } else if (var == "LOG_INTERVAL") {
      LOG_INTERVAL = valeur.toInt();
      EEPROM.put(0, LOG_INTERVAL);
      Serial.println("Commande exécutée avec succès !"); 
    } else if (var == "FILE_MAX_SIZE") {
      FILE_MAX_SIZE = valeur.toInt();
      EEPROM.put(2, FILE_MAX_SIZE);
      Serial.println("Commande exécutée avec succès !"); 
    } else if (var == "TIMEOUT") {
      TIMEOUT = valeur.toInt();
      EEPROM.put(4, TIMEOUT);
      Serial.println("Commande exécutée avec succès !"); 
    } else if (var == "LUMIN") {
      if (valeurInt >= 0 && valeurInt <= 1) {
      LUMIN = valeur.toInt();
      EEPROM.put(6, LUMIN);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : LUMIN_LOW doit être compris entre 0 et 1");
      }
    } else if (var == "LUMIN_LOW") {
      if (valeurInt >= 0 && valeurInt <= 1023) {
      LUMIN_LOW = valeur.toInt();
      EEPROM.update(7, LUMIN_LOW);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : LUMIN_LOW doit être compris entre 0 et 1023");
      }
    } else if (var == "LUMIN_HIGH") {
      if (valeurInt >= 0 && valeurInt <= 1023) {
      LUMIN_HIGH = valeur.toInt();
      EEPROM.put(9, LUMIN_HIGH);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : LUMIN_HIGH doit être compris entre 0 et 1023");
      }
    } else if (var == "TEMP_AIR") {
      if (valeurInt >= 0 && valeurInt <= 1) {
      TEMP_AIR = valeur.toInt();
      EEPROM.put(11, TEMP_AIR);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : TEMP_AIR doit être compris entre 0 et 1");
      }
    } else if (var == "MIN_TEMP_AIR") {
      if (valeurInt >= -40 && valeurInt <= 85) {
      MIN_TEMP_AIR = valeur.toInt();
      EEPROM.put(12, MIN_TEMP_AIR);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : MIN_TEMP_AIR doit être compris entre -40 et 85");
      }
    } else if (var == "MAX_TEMP_AIR") {
      if (valeurInt >= -40 && valeurInt <= 85) {
      MAX_TEMP_AIR = valeur.toInt();
      EEPROM.put(14, MAX_TEMP_AIR);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : MAX_TEMP_AIR doit être compris entre -40 et 85");
      }
    } else if (var == "HYGR") {
      if (valeurInt >= 0 && valeurInt <= 1) {
      HYGR = valeur.toInt();
      EEPROM.put(15, HYGR);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : HYGR doit être compris entre 0 et 1");
      }
    } else if (var == "HYGR_MINT") {
      if (valeurInt >= -40 && valeurInt <= 85) {
      HYGR_MINT = valeur.toInt();
      EEPROM.put(16, HYGR_MINT);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : HYGR_MINT doit être compris entre -40 et 85");
      }
    } else if (var == "HYGR_MAXT") {
      if (valeurInt >= -40 && valeurInt <= 85) {
      HYGR_MAXT = valeur.toInt();
      EEPROM.put(18, HYGR_MAXT);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : HYGR_MAXT doit être compris entre -40 et 85");
      }
    } else if (var == "PRESSURE") {
      if (valeurInt >= 0 && valeurInt <= 1) {
      PRESSURE = valeur.toInt();
      EEPROM.put(19, PRESSURE);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : PRESSURE doit être compris entre 0 et 1");
      }
    } else if (var == "PRESSURE_MIN") { 
      if (valeurInt >= 300 && valeurInt <= 1100) {
      PRESSURE = valeur.toInt();
      EEPROM.put(20, PRESSURE_MIN);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : PRESSURE_MIN doit être compris entre 300 et 1100");
      }

    } else if (var == "PRESSURE_MAX") {
      if (valeurInt >= 300 && valeurInt <= 1100) {
      PRESSURE_MAX = valeur.toInt();
      EEPROM.put(22, PRESSURE_MAX);
      Serial.println("Commande exécutée avec succès !"); 
      } else {
        Serial.println("Erreur : PRESSURE_MAX doit être compris entre 300 et 1100");
      }
    } else {
      Serial.println("Erreur : Paramètre invalide");
    }
  } else {
    Serial.println("Erreur : commande invalide");
  }

   Serial.println("Entrez une nouvelle commande:");
    }
  }
}
}

void loop()
{

}
