#include <Arduino.h>
#include <ChainableLED.h>
#include <SparkFunBME280.h>
#include <Wire.h>

// Définition des pins et constantes
#define pinLumSensor A2
#define TAILLE_FENETRE 10

// Déclaration des objets pour les capteurs
BME280 tphSensor;
ChainableLED leds(7, 8, 1);

// Structure pour stocker les données des capteurs
struct DonneesCapteurs {
    float luminosite;
    float pression;
    float humidite;
    float temperature;
};

// Structure pour gérer les moyennes glissantes
struct MoyenneGlissante {
    float valeursLuminosite[TAILLE_FENETRE];
    float valeursPression[TAILLE_FENETRE];
    float valeursHumidite[TAILLE_FENETRE];
    float valeursTemperature[TAILLE_FENETRE];
    int indice;
};

MoyenneGlissante mg = {0}; // Initialisation de la structure

// Fonction de lecture des capteurs
DonneesCapteurs lireCapteurs() {
    DonneesCapteurs donnees;
    donnees.luminosite = analogRead(pinLumSensor);
    donnees.pression = tphSensor.readFloatPressure();
    donnees.humidite = tphSensor.readFloatHumidity();
    donnees.temperature = tphSensor.readTempC();
    return donnees;
}

// Calcul de la moyenne glissante pour un tableau donné
float calculerMoyenneGlissante(float valeurs[]) {
    float somme = 0.0f;
    for (int i = 0; i < TAILLE_FENETRE; i++) {
        somme += valeurs[i];
    }
    return somme / TAILLE_FENETRE;
}

// Mise à jour des moyennes glissantes
void mettreAJourMoyennes(DonneesCapteurs* donnees) {
    // Stockage des nouvelles valeurs
    mg.valeursLuminosite[mg.indice] = donnees->luminosite;
    mg.valeursPression[mg.indice] = donnees->pression;
    mg.valeursHumidite[mg.indice] = donnees->humidite;
    mg.valeursTemperature[mg.indice] = donnees->temperature;
    
    // Calcul des moyennes
    donnees->luminosite = calculerMoyenneGlissante(mg.valeursLuminosite);
    donnees->pression = calculerMoyenneGlissante(mg.valeursPression);
    donnees->humidite = calculerMoyenneGlissante(mg.valeursHumidite);
    donnees->temperature = calculerMoyenneGlissante(mg.valeursTemperature);
    
    // Mise à jour de l'indice circulaire
    mg.indice = (mg.indice + 1) % TAILLE_FENETRE;
}

// Affichage des données sur le port série
void afficherDonnees(const DonneesCapteurs* donnees) {
    Serial.print("Luminosite : ");
    Serial.print(donnees->luminosite);
    Serial.print("      ");
    
    Serial.print("Pression : ");
    Serial.print(donnees->pression/100);
    Serial.print(" hPa");
    Serial.print("      ");
    
    Serial.print("Humidite : ");
    Serial.print(donnees->humidite);
    Serial.print(" %");
    Serial.print("      ");
    
    Serial.print("Temperature : ");
    Serial.print(donnees->temperature);
    Serial.println(" °C");
}

void setup() {
    Serial.begin(9600);
    Wire.begin();
    
    // Initialisation du BME280
    tphSensor.setI2CAddress(0x76);
    if (tphSensor.beginI2C()) {
        Serial.println("BME280 initialise avec succes");
        tphSensor.setMode(MODE_NORMAL);
    } else {
        Serial.println("Erreur d'initialisation BME280");
    }
    
    // Configuration des pins
    pinMode(pinLumSensor, INPUT);
    
    // Initialisation de la LED
    leds.setColorRGB(0, 0, 255, 0); // LED verte au démarrage
}

void loop() {
    // Lecture des capteurs
    DonneesCapteurs donnees = lireCapteurs();
    
    // Mise à jour des moyennes
    mettreAJourMoyennes(&donnees);
    
    // Affichage des données
    afficherDonnees(&donnees);
    
    // Attente avant la
    delay(1000);
}
